*This project has been created as part of the 42 curriculum by <msobral-@student.42lisboa.com>, <lyokoiga@student.42lisboa.com>.*
<br/><br/>
<h1 align="center">🧩 a-MAZE-ing</h1>

<p align="center">
  Procedurally generating mazes one cell at a time! Something something Daedalus.
</p>
<p align="center">
    <img src="https://img.shields.io/github/languages/top/miguelsobralcurado/a-MAZE-ing?style=for-the-badge" />
    <img src="https://img.shields.io/github/last-commit/miguelsobralcurado/a-MAZE-ing?style=for-the-badge" />
    <img src="https://img.shields.io/github/contributors/miguelsobralcurado/a-MAZE-ing?style=for-the-badge" />
</p>
<table>
    <tbody>
        <tr>
            <td align="right" valign="top" width="14.28%"><a href="https://github.com/miguelsobralcurado"><img src="https://avatars.githubusercontent.com/u/174656941?v=4" width="100px;" alt="Lyokoigawa"/><br /><sub><b>Miguel Sobral Curado</b></sub></a><br /><a href="#question-kentcdodds" title="Answering Questions">💬</a> <a href="https://github.com/all-contributors/allcontributors.org/commits?author=kentcdodds" title="Documentation">📖</a></td>
            <td align="left" valign="top" width="14.28%"><a href="https://github.com/Lyokoigawa"><img src="https://avatars.githubusercontent.com/u/78232506?v=4" width="100px;" alt="Lyokoigawa"/><br /><sub><b>Lyokoigawa</b></sub></a><br /><a href="#question-kentcdodds" title="Answering Questions">💬</a> <a href="https://github.com/all-contributors/allcontributors.org/commits?author=kentcdodds" title="Documentation">📖</a></td>
        </tr>
    </tbody>
</table>

https://shields.io/badges/git-hub-last-commit
https://shields.io/badges/git-hub-contributors

## Description

A-Maze-ing is a configurable maze generation program written in Python that produces a solvable, fully connected maze, that can be perfect or imperfect (Meaning it has only one possible solution between entry and exit).

The project demonstrates applications of:

- Graph theory (Spenning trees)
- Randomized algorithms
- File parsing and validation
- Data encoding (bitwise hexadecimal representation)
- Visualization techniques using ASCII

The programs reads a configuration file (config.txt), 

## Instructions



## 



## Resources
https://github.com/foundersandcoders/git-workflow-workshop-for-two


https://www.youtube.com/watch?v=V1oZQm1HtVw
https://github.com/JTexpo/Maze_Solver_BFS/blob/main/maze_solver_bfs/maze_solver.py
https://www.geeksforgeeks.org/dsa/count-number-of-ways-to-reach-destination-in-a-maze-using-bfs/

### 🤖 AI Contributions



python3 -m venv .venv

source .venv/bin/activate

python -m pip install --upgrade pip build wheel setuptools

python -m build

pip install mazegen-1.0.0.tar.gz